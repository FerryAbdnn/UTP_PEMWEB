<h2>Daftar Menu</h2>
<table>
    <tr>
        <th>Minuman</th>
        <th>Harga</th>
    </tr>
    <tr>
        <td>Kopi Susu Tobi</td>
        <td>Rp18.000</td>
    </tr>
    <tr>
        <td>Americano</td>
        <td>Rp15.000</td>
    </tr>
    <tr>
        <td>Matcha Latte</td>
        <td>Rp22.000</td>
    </tr>
    <tr>
        <td>Kopi Tubruk</td>
        <td>Rp30.000</td>
    </tr>
    <tr>
        <td>Teh MGM</td>
        <td>Rp100.000</td>
    </tr>
</table>

<h2>Form Pemesanan</h2>
<form action="proses.php" method="post">
    <label for="nama">Nama:</label>
    <input type="text" id="nama" name="nama" required><br><br>

    <label for="menu">Minuman:</label>
    <select id="menu" name="menu" required>
        <option value="">Pilih Minuman</option>
        <option value="kopi_susu_tobi">Kopi Susu Tobi</option>
        <option value="americano">Americano</option>
        <option value="matcha_latte">Matcha Latte</option>
        <option value="kopi_tubruk">Kopi Tubruk</option>
        <option value="teh_mgm">Teh MGM</option>
    </select><br><br>

    <label for="jumlah">Jumlah:</label>
    <input type="number" id="jumlah" name="jumlah" required><br><br>

    <label for="kategori">Kategori Pelanggan:</label>
    <select id="kategori" name="kategori" required>
        <option value="">Pilih Kategori</option>
        <option value="reguler">Reguler</option>
        <option value="member">Member</option>
    </select><br><br>

    <input type="submit" value="Pesan">
</form>