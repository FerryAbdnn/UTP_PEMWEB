<?php
$nama = $_POST["nama"];
$menu = $_POST["menu"];
$jumlah = (int) $_POST["jumlah"];
$kategori = $_POST["kategori"];

$valid = true;
$pesan = "";

$daftar_harga = [
    "kopi_susu_tobi" => 18000,
    "americano" => 15000,
    "matcha_latte" => 22000,
    "kopi_tubruk" => 30000,
    "teh_mgm" => 100000
];

$daftar_nama_menu = [
    "kopi_susu_tobi" => "Kopi Susu Tobi",
    "americano" => "Americano",
    "matcha_latte" => "Matcha Latte",
    "kopi_tubruk" => "Kopi Tubruk",
    "teh_mgm" => "Teh MGM"
];

if (!isset($daftar_harga[$menu])) {
    $valid = false;
    $pesan = "Menu tidak tersedia";
} else {
    $harga = $daftar_harga[$menu];
    $nama_menu = $daftar_nama_menu[$menu];
}

if ($jumlah <= 0) {
    $valid = false;
    $pesan = "Jumlah harus lebih dari 0";
}

if ($kategori !== "reguler" && $kategori !== "member") {
    $valid = false;
    $pesan = "Kategori pelanggan tidak valid";
}

if ($valid) {
    $subtotal = $jumlah * $harga;

    $diskon = 0;
    if ($kategori === "member" && $jumlah >= 3) {
        $diskon = 0.10 * $subtotal;
    }

    $total = $subtotal - $diskon;
} else {
    $harga = 0;
    $subtotal = 0;
    $diskon = 0;
    $total = 0;
}

$pesangagal = $pesan;
?>