<?php
$_SESSION["nama"] = $nama;
$_SESSION["menu"] = $nama_menu ?? $menu;
$_SESSION["harga"] = $harga;
$_SESSION["jumlah"] = $jumlah;
$_SESSION["kategori"] = $kategori;
$_SESSION["subtotal"] = $subtotal;
$_SESSION["diskon"] = $diskon;
$_SESSION["total"] = $total;
?>