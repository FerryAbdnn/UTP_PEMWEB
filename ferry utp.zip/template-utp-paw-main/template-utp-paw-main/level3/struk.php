<?php
if (!isset($_SESSION["nama"])) {
    echo "<p>Belum ada pesanan.</p>";
} else {
    $nama = htmlspecialchars($_SESSION["nama"]);
    $menu = htmlspecialchars($_SESSION["menu"]);
    $kategori = ucfirst($_SESSION["kategori"]);

    echo "<h2>Struk Pesanan</h2>";
    echo "<p>Nama Pelanggan: $nama</p>";
    echo "<p>Minuman: $menu</p>";
    echo "<p>Harga Satuan: Rp" . number_format($_SESSION["harga"], 0, ",", ".") . "</p>";
    echo "<p>Jumlah: " . $_SESSION["jumlah"] . " gelas</p>";
    echo "<p>Kategori Pelanggan: $kategori</p>";
    echo "<hr>";
    echo "<p>Subtotal: Rp" . number_format($_SESSION["subtotal"], 0, ",", ".") . "</p>";
    echo "<p>Diskon: Rp" . number_format($_SESSION["diskon"], 0, ",", ".") . "</p>";
    echo "<p><strong>Total Bayar: Rp" . number_format($_SESSION["total"], 0, ",", ".") . "</strong></p>";
}
?>