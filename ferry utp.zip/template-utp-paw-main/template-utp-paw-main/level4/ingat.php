<?php
$durasi = (1 * 86400) + (2 * 3600) + (22 * 60);
setcookie("nama_pelanggan", $nama, time() + $durasi, "/");
?>