<?php
if (isset($_COOKIE["nama_pelanggan"])) {
    $nama_sapaan = htmlspecialchars($_COOKIE["nama_pelanggan"]);
    echo "<p>Selamat datang kembali, $nama_sapaan!</p>";
} else {
    echo "<p>Selamat datang di Kedai Kopi Tobi!</p>";
}
?>